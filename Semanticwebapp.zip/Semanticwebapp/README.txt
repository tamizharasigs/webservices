Simple Eclipse based editors for Semantic Web Languages (Turtle, Jena rules, etc.).


